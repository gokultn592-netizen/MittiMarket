const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const port = process.env.PORT || 8080;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Explicit route for debugging/serving the root React/HTML app
app.get('/', (req, res) => {
    const indexPath = path.join(__dirname, 'public', 'index.html');
    if (fs.existsSync(indexPath)) res.sendFile(indexPath);
    else res.status(404).send("<h2>MittiMart API is Live!</h2><p>Wait! The 'public' directory containing index.html was not found.</p>");
});

// ============================================
// DATABASE REDESIGN (MongoDB via Mongoose)
// ============================================
mongoose.connect('mongodb://127.0.0.1:27017/mittimart')
    .then(() => console.log("Connected to MongoDB natively"))
    .catch(err => console.error("MongoDB ERROR:", err));

// Schemas
const productSchema = new mongoose.Schema({
    name: String,
    description: String,
    category: String,
    tags: [String], // e.g. ["clay", "handmade", "village"]
    image_url: String,
    image_query: String,
    stock: { type: Number, default: 0 },
    price: { type: Number, default: 0 },
    created_at: { type: Date, default: Date.now }
});
const Product = mongoose.model('Product', productSchema);

const orderSchema = new mongoose.Schema({
    user_id: String, // Kept as string for legacy support, or you can use ObjectId
    products: [String],
    total_price: Number,
    status: { type: String, default: "pending" },
    created_at: { type: Date, default: Date.now }
});
const Order = mongoose.model('Order', orderSchema);

// Legacy Mock DB (for routes not fully ported to Mongo yet, like users/carts/wishlists)
let db = { users: [], carts: {}, wishlists: {}, nextUserId: 1001 };
const DB_FILE = path.join(__dirname, 'database.json');
if (fs.existsSync(DB_FILE)) {
    try {
        const data = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(data);
        db.users = parsed.users || []; db.carts = parsed.carts || {}; db.wishlists = parsed.wishlists || {};
    } catch(err) { console.error('Error reading legacy db', err); }
}
function saveLegacyDb() { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

// ============================================
// IMAGE & VALIDATION LOGIC
// ============================================
function generateImageQuery(productBody) {
    const name = productBody.name || "";
    const tags = productBody.tags || [];
    const materials = ["clay", "brass", "wood", "palm leaf", "cotton"];
    
    let materialStr = "";
    for (const t of tags) {
        if (materials.includes(t.toLowerCase())) materialStr = t;
    }
    
    const context = tags.includes("temple") ? "temple" : (tags.includes("kitchen") ? "village kitchen" : "village styled");
    return `authentic traditional Tamil Nadu ${materialStr} ${name} ${context}`.trim();
}

function validateImage(product, metadataContext = "") {
    let flag = "valid";
    if (!product.image_url) {
        flag = "missing";
    } else {
        const queryMetadataLower = (product.image_query + " " + metadataContext).toLowerCase();
        let matchCount = 0;
        const tags = product.tags || [];
        tags.forEach(tag => {
            if (queryMetadataLower.includes(tag.toLowerCase())) matchCount++;
        });
        if (tags.length > 0 && matchCount === 0) flag = "invalid";
    }
    return flag;
}

// ============================================
// REAL-TIME ADMIN DASHBOARD (WebSockets)
// ============================================
io.on('connection', (socket) => {
    console.log("Monitor/Admin connected:", socket.id);
});

function emitAdminAlert(type, message, data) {
    io.emit('admin_alert', { type, message, data, timestamp: new Date() });
}

// ============================================
// REST API ROUTES
// ============================================

// --- Products (MongoDB) ---
app.get('/api/products', async (req, res) => {
    try {
        const products = await Product.find({});
        res.json(products);
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/products', async (req, res) => {
    try {
        const newProdData = {
            name: req.body.name,
            description: req.body.description,
            category: req.body.category,
            tags: req.body.tags || [],
            image_url: req.body.img || req.body.image_url,
            stock: req.body.stock || 0,
            price: req.body.price || 0
        };
        // 1. Generate Query
        newProdData.image_query = generateImageQuery(newProdData);
        
        // 2. Validate logic
        const validFlag = validateImage(newProdData, "");
        if (validFlag === "missing") emitAdminAlert("Missing Product Image", `Product ${newProdData.name} has no image.`, newProdData);
        if (validFlag === "invalid") emitAdminAlert("Mismatched Image", `Product ${newProdData.name} image might be misrepresenting the real product.`, newProdData);

        const prod = new Product(newProdData);
        await prod.save();
        io.emit('product_added', prod); // Live product preview
        res.status(201).json(prod);
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/products/:id', async (req, res) => {
    try {
        const prod = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if(!prod) return res.status(404).json({error: "Not found"});
        
        // Alert if low stock
        if (prod.stock < 5) emitAdminAlert("Low Stock", `Product ${prod.name} has low stock (${prod.stock}).`, prod);
        
        io.emit('product_updated', prod);
        res.json(prod);
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/products/:id', async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        io.emit('product_deleted', req.params.id);
        res.json({success: true});
    } catch(err) { res.status(500).json({ error: err.message }); }
});

// --- Orders (MongoDB) ---
app.get('/api/orders', async (req, res) => {
    try {
        const orders = await Order.find({});
        res.json(orders);
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/orders', async (req, res) => {
    try {
        const newOrder = new Order(req.body);
        await newOrder.save();
        io.emit('new_order', newOrder); // Real-time Order Tracking
        res.status(201).json(newOrder);
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/orders/:id/status', async (req, res) => {
    try {
        const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
        if(!order) return res.status(404).json({error: "Not found"});
        io.emit('order_status_update', order);
        res.json(order);
    } catch(err) { res.status(500).json({ error: err.message }); }
});


// ============================================
// LEGACY AUTH & USERS (Retained for frontend)
// ============================================
app.post('/api/auth/register', (req, res) => {
    const { name, phone, password, role } = req.body;
    const user = { id: (db.nextUserId++).toString(), name, phone, password, role };
    db.users.push(user); saveLegacyDb();
    io.emit('user_activity', { action: "register", user: user.name }); // User Activity Tracking
    res.status(201).json({ user });
});

app.post('/api/auth/login', (req, res) => {
    const { phone, password } = req.body;
    const user = db.users.find(u => u.phone === phone && u.password === password);
    if (!user) return res.status(401).json({ error: "Invalid credentials" });
    io.emit('user_activity', { action: "login", user: user.name });
    res.json({ user });
});

// Analytics Hook (Example endpoint for Admin Dashboard Analytics Data)
app.get('/api/analytics', async (req, res) => {
    const orders = await Order.find({});
    let totalSales = 0;
    orders.forEach(o => totalSales += (o.total_price || 0));
    res.json({ salesTrends: totalSales, totalOrders: orders.length });
});

// START
server.listen(port, () => {
    console.log(`MittiMart Backend (Mongo+WebSockets) running on port ${port}`);
});
