// Include mongoose C library
#include "mongoose.h"
#include "json.hpp"
#include "backend.cpp"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <map>

using json = nlohmann::json;
using namespace MittiMart;

json db;

void saveDb() {
    std::ofstream ofs("database.json");
    if (ofs.is_open()) {
        ofs << db.dump();
    }
}

void loadDb() {
    std::ifstream ifs("database.json");
    if(ifs.good()){
        try {
            ifs >> db;
        } catch (...) {
            std::cerr << "MittiMart: Failed to parse database.json, initializing fresh." << std::endl;
        }
    }
    
    if(!db.contains("users")) db["users"] = json::array();
    if(!db.contains("products")) db["products"] = json::array();
    if(!db.contains("carts")) db["carts"] = json::object();
    if(!db.contains("wishlists")) db["wishlists"] = json::object();
    if(!db.contains("orders")) db["orders"] = json::array();
    if(!db.contains("nextOrderId")) db["nextOrderId"] = 1001;
    if(!db.contains("nextUserId")) db["nextUserId"] = 501;
    if(!db.contains("nextProductId")) db["nextProductId"] = 19;
    
    // Auto-generate 100 unique farm products with stunning category-relevant images if not present
    if (db["products"].size() != 100) {
        db["products"] = json::array();
        std::vector<std::string> adjs = {"Fresh", "Organic", "Village", "Pure", "Naattu", "Traditional", "A1", "Farm Picked", "Premium", "Raw"};
        
        std::map<std::string, std::pair<std::string, std::string>> productsData = {
            {"A2 Milk", {"dairy", "images/mittimart_a2_milk_1774719413119.png"}},
            {"Black Rice", {"rice", "images/mittimart_black_rice_1774717842790.png"}},
            {"Natural Clay Pot", {"earthenware", "images/mittimart_clay_pot_1774718092274.png"}},
            {"Fresh Curd", {"dairy", "images/mittimart_curd_1774719450813.png"}},
            {"Organic Drumsticks", {"vegetables", "images/mittimart_drumsticks_1774717990482.png"}},
            {"Filter Coffee", {"snacks", "images/mittimart_filter_coffee_1774718066731.png"}},
            {"Groundnut Oil", {"oils", "images/mittimart_groundnut_oil_1774717878748.png"}},
            {"Jaggery Blocks", {"snacks", "images/mittimart_jaggery_1774717954723.png"}},
            {"Mango", {"fruits", "images/mittimart_mango_1774718027608.png"}},
            {"Fresh Paneer", {"dairy", "images/mittimart_paneer_1774719431118.png"}},
            {"Pearl Millet", {"millets", "images/mittimart_pearl_millet_1774717937515.png"}},
            {"Ragi Flour", {"millets", "images/mittimart_ragi_1774717916507.png"}},
            {"Red Banana", {"fruits", "images/mittimart_red_banana_1774718046416.png"}},
            {"Red Rice", {"rice", "images/mittimart_red_rice_1774717862093.png"}},
            {"Pure Sesame Oil", {"oils", "images/mittimart_sesame_oil_1774717895512.png"}},
            {"Small Onions", {"vegetables", "images/mittimart_small_onions_1774718011186.png"}},
            {"Tomatoes", {"vegetables", "images/mittimart_tomatoes_1774717972229.png"}},
            {"Desi Ghee", {"dairy", "images/user_desi_ghee.jpg"}}
        };
        
        std::vector<std::string> keys;
        for (std::map<std::string, std::pair<std::string, std::string>>::iterator it = productsData.begin(); it != productsData.end(); ++it) {
            keys.push_back(it->first);
        }
        
        int nextId = 1;
        int count = 0;
        std::vector<std::string> usedCombinations;

        while(count < 100) {
            std::string adj = adjs[rand() % adjs.size()];
            std::string base = keys[rand() % keys.size()];
            std::string combo = adj + " " + base;
            
            bool found = false;
            for (size_t k = 0; k < usedCombinations.size(); k++) {
                if (usedCombinations[k] == combo) { found = true; break; }
            }
            
            if (!found) {
                usedCombinations.push_back(combo);
                std::string cat = productsData[base].first;
                std::string imgUrl = productsData[base].second;
                
                json p = {
                    {"id", nextId++},
                    {"sellerId", 101},
                    {"name", combo},
                    {"category", cat},
                    {"price", (rand() % 400) + 20.0},
                    {"unit", "1 kg"},
                    {"stock", (rand() % 100) + 10},
                    {"rating", 4.0 + (rand() % 10) / 10.0},
                    {"reviews", rand() % 500},
                    {"img", imgUrl}
                };
                db["products"].push_back(p);
                count++;
            }
        }
        db["nextProductId"] = nextId;
        saveDb();
    }
}

// Mongoose HTTP Event Handler
static void fn(struct mg_connection *c, int ev, void *ev_data) {
  if (ev == MG_EV_HTTP_MSG) {
    struct mg_http_message *hm = (struct mg_http_message *) ev_data;
    
    // Allow Preflight CORS
    if (mg_match(hm->method, mg_str("OPTIONS"), NULL)) {
        mg_http_reply(c, 200, "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\n", "");
        return;
    }

    if (mg_match(hm->uri, mg_str("/api/db"), NULL)) {
      std::string dumped = db.dump();
      mg_printf(c, "HTTP/1.1 200 OK\r\n"
                   "Access-Control-Allow-Origin: *\r\n"
                   "Content-Type: application/json\r\n"
                   "Content-Length: %d\r\n\r\n"
                   "%s", (int)dumped.size(), dumped.c_str());
      
    } else if (mg_match(hm->uri, mg_str("/api/sync"), NULL)) {
      try {
        std::string body(hm->body.buf, hm->body.len);
        json incoming = json::parse(body);
        db = incoming;
        saveDb();
        
        std::string res = "{\"success\":true}";
        mg_printf(c, "HTTP/1.1 200 OK\r\n"
                     "Access-Control-Allow-Origin: *\r\n"
                     "Content-Type: application/json\r\n"
                     "Content-Length: %d\r\n\r\n"
                     "%s", (int)res.size(), res.c_str());
      } catch(...) {
        mg_http_reply(c, 400, "Access-Control-Allow-Origin: *\r\nContent-Type: application/json\r\n", "{\"error\":\"Invalid parsing\"}");
      }
    } else {
      // Serve index.html and static files natively mimicking Express layout
      struct mg_http_serve_opts opts = {0};
      opts.root_dir = "./public";
      mg_http_serve_dir(c, hm, &opts);
    }
  }
}

int main(void) {
  loadDb();
  
  struct mg_mgr mgr;
  mg_mgr_init(&mgr);
  const char* port = "http://0.0.0.0:8080";
  if (mg_http_listen(&mgr, port, fn, NULL) == NULL) {
      std::cerr << "Failed to listen on port 8080\n";
      return 1;
  }
  
  std::cout << "MittiMart Native C++ Engine ALIVE on " << port << " (Mongoose Loop)...\n";
  for (;;) mg_mgr_poll(&mgr, 500);
  
  mg_mgr_free(&mgr);
  return 0;
}
